﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class keyCheckerScript : MonoBehaviour {
	[SerializeField]
	private InputField input;

	void Awake(){
//		input = GameObject.Find ("InputField").GetComponent<InputField>;
	}

	public void GetInput(string code)
	{
		Debug.Log ("i"+code);
		input.text = "";
	}
}